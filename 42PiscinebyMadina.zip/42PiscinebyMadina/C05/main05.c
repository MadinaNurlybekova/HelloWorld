/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main05.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/23 12:15:38 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/24 11:42:15 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
// #include "ex00/ft_iterative_factorial.c"
// #include "ex01/ft_recursive_factorial.c"
// #include "ex02/ft_iterative_power.c"
// #include "ex03/ft_recursive_power.c"
// #include "ex04/ft_fibonacci.c"
// #include "ex05/ft_sqrt.c"
// #include "ex06/ft_is_prime.c"
// #include "ex07/ft_find_next_prime.c"


int main(void)
{
    // 00
    // printf("ex00\n");
    // printf("%d\n", ft_iterative_factorial(4));
    // printf("%d\n", ft_iterative_factorial(12));
    // printf("%d\n", ft_iterative_factorial(1));
    // printf("%d\n", ft_iterative_factorial(0));
    // printf("%d\n", ft_iterative_factorial(13));
    // printf("%d\n", ft_iterative_factorial(-5));

    // 01
    // printf("ex01\n");
    // printf("%d\n", ft_recursive_factorial(5));
    // printf("%d\n", ft_recursive_factorial(12));
    // printf("%d\n", ft_recursive_factorial(-5));
    // printf("%d\n", ft_recursive_factorial(0));
    // printf("%d\n", ft_recursive_factorial(13));

    // 02
    // printf("ex02\n");
    // printf("%d\n", ft_iterative_power(100, 4));
    // printf("%d\n", ft_iterative_power(2, 6));
    // printf("%d\n", ft_iterative_power(0, 0));
    // printf("%d\n", ft_iterative_power(5, 0));
    // printf("%d\n", ft_iterative_power(5, -1));

    // 03
    // printf("ex03\n");
    // printf("%d\n", ft_recursive_power(100, 5));
    // printf("%d\n", ft_recursive_power(2, 6));
    // printf("%d\n", ft_recursive_power(0, 0));
    // printf("%d\n", ft_recursive_power(5, 1));
    // printf("%d\n", ft_recursive_power(5, -1));
    
    // 04
    // printf("ex04\n");
    // printf("%d\n", ft_fibonacci(6));
    // printf("%d\n", ft_fibonacci(0));
    // printf("%d\n", ft_fibonacci(1));
    // printf("%d\n", ft_fibonacci(10));
    // printf("%d\n", ft_fibonacci(-20));

    //05
    // printf("ex05\n");
    // printf("%d\n", ft_sqrt(2));
    // printf("%d\n", ft_sqrt(-2));
    // printf("%d\n", ft_sqrt(6));
    // printf("%d\n", ft_sqrt(81));
    // printf("%d\n", ft_sqrt(121));
    // printf("%d\n", ft_sqrt(2147395600));
    // printf("%d\n", ft_sqrt(2147483647));

    //06
    // printf("ex06\n");
    // printf("%d\n", ft_is_prime(2));
    // printf("%d\n", ft_is_prime(3));
    // printf("%d\n", ft_is_prime(5));
    // printf("%d\n", ft_is_prime(11));
    // printf("%d\n", ft_is_prime(4));
    // printf("%d\n", ft_is_prime(6));

    //07
    // printf("ex07\n");
    // printf("%d\n", ft_find_next_prime(2147483643));
    // printf("%d\n", ft_find_next_prime(3));
    // printf("%d\n", ft_find_next_prime(4));
    // printf("%d\n", ft_find_next_prime(5));
    // printf("%d\n", ft_find_next_prime(60));
    // printf("%d\n", ft_find_next_prime(15));
    // printf("%d\n", ft_find_next_prime(9));
    // printf("%d\n", ft_find_next_prime(2147483644));
    // printf("%d\n", ft_find_next_prime(2147483645));
    // printf("%d\n", ft_find_next_prime(2147483646));
    // printf("%d\n", ft_find_next_prime(2147483647));
   
    return (0);
}