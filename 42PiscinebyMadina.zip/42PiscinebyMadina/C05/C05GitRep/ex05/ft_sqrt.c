/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/23 15:52:29 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/23 17:26:32 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	long	x;
	long	nb_l;

	nb_l = nb;
	x = 1;
	if (nb <= 0)
		return (0);
	if (nb == 1)
		return (1);
	while (x * x < nb_l)
	{
		x++;
	}
	if (nb_l == x * x)
		return ((int) x);
	else
		return (0);
}
