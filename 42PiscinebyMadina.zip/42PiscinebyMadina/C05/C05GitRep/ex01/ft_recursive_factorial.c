/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/23 13:27:32 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/23 15:31:52 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	int	x;

	x = nb;
	if (nb <= 0 || nb > 12)
		return (0);
	if (nb > 1)
		x = x * ft_recursive_factorial(nb - 1);
	return (x);
}
