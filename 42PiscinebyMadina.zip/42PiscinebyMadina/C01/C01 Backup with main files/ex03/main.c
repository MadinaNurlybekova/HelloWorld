/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 09:29:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:05:57 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_div_mod.c"

void	ft_div_mod(int a, int b, int *div, int*mod);

int	main(void)
{
	int	a;
	int	b;
	int	*div;
	int	*mod;
	int	division;
	int	module;

	a = 56;
	b = 10;
	div = &division;
	mod = &module;
	ft_div_mod(a, b, div, mod);
	printf("%d\n", division);
	printf("%d", module);
	return (0);
}
