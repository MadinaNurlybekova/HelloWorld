/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 09:29:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:11:03 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_putstr.c"

void	ft_putstr(char *str);

int	main(void)
{
	char	arr[] = "sd';lamdlkvm";
	char	*str;

	str = arr;
	ft_putstr(str);
	return (0);
}
