/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 09:29:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:03:57 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_swap.c"

void	ft_swap(int *a, int *b);

int	main(void)
{
	int	a;
	int	b;
	int	*ptr_to_a;
	int	*ptr_to_b;

	a = 654;
	b = 3256;
	ptr_to_a = &a;
	ptr_to_b = &b;
	ft_swap(ptr_to_a, ptr_to_b);
	printf("%d\n", a);
	printf("%d", b);
	return (0);
}
