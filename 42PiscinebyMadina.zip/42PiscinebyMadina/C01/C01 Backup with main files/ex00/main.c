/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 13:51:01 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 13:52:10 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_ft.c"

void	ft_ft(int *nbr);

int	main(void)
{
	int	i;
	int	*ptr;

	ptr = &i;
	ft_ft(ptr);
	printf("%d", i);
	return (0);
}
