/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 12:02:54 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:15:28 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	temp;
	int	i;
	int	len;

	i = 0;
	len = size - 1;
	while (len > i)
	{
		temp = (tab[len]);
		(tab[len]) = (tab[i]);
		(tab[i]) = temp;
		i++;
		len--;
	}
}
