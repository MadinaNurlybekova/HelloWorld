/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 09:29:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:15:26 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_rev_int_tab.c"

void	ft_rev_int_tab(int *tab, int size);

int	main(void)
{
	int	tab[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	int	size;
	int	*ptr_to_tab;

	ptr_to_tab = tab;
	size = *(&tab + 1) - tab;
	ft_rev_int_tab(ptr_to_tab, size);
	//print array to check if the numbers are reversed:
	for (int i = 0; i < size; ++i)
	{
		printf("%d", tab[i]);
		printf(" ");
	}
	return (0);
}
