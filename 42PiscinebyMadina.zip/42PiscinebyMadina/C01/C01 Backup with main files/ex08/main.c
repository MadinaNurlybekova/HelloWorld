/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 09:29:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:18:18 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_sort_int_tab.c"

void	ft_sort_int_tab(int *tab, int size);

int	main(void)
{
	int	tab[] = {1, 84, 561, 21, 94, 1000, 3, 5, 4, 89, 654, 23, 23};
	int	size;
	int	*ptr_to_tab;

	ptr_to_tab = tab;
	size = *(&tab + 1) - tab; //define the size of an array
	//printf("%d", size);
	ft_sort_int_tab(ptr_to_tab, size);
	//print array to check if the numbers are reversed:
	for (int i = 0; i < size; ++i)
	{
		printf("%d", tab[i]);
		printf(" ");
	}
	return (0);
}
