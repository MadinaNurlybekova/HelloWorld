/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 09:29:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 14:07:47 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_ultimate_div_mod.c"

void	ft_ultimate_div_mod(int *a, int *b);

int	main(void)
{
	int	a;
	int	b;
	int	*ptr_to_a;
	int	*ptr_to_b;

	a = 85;
	b = 9;
	ptr_to_a = &a;
	ptr_to_b = &b;
	ft_ultimate_div_mod(ptr_to_a, ptr_to_b);
	printf("%d\n", a);
	printf("%d", b);
	return (0);
}
