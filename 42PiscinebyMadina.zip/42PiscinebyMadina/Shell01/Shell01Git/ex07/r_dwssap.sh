cat -e /etc/passwd | awk -F ':' '{print $1""}' | awk 'FNR%2==0' | rev | sort -r |awk 'FNR>= ENVIRON["FT_LINE1"] && FNR <= ENVIRON["FT_LINE2"]' | tr '\n' ',' | sed 's/,/, /g' | sed 's/, $/./'

