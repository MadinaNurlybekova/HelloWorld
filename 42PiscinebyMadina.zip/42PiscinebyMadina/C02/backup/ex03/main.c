/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 12:17:28 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_str_is_numeric.c"

int	ft_str_is_numeric(char *str);

int	main(void)
{

	// printf("%d\n", ft_str_is_alpha(ptr1));
	// printf("%d\n", ft_str_is_alpha(ptr2));
	// printf("%d\n", ft_str_is_alpha(ptr3));
	// printf("%d\n", ft_str_is_alpha(ptr4));
	printf("%d", ft_str_is_numeric(""));
	printf("\n%d", ft_str_is_numeric("asd48"));
	printf("\n%d", ft_str_is_numeric("58564687"));
	printf("\n%d", ft_str_is_numeric("585 64687"));
	printf("\n%d", ft_str_is_numeric("58564sdffs/687"));
	printf("\n%d", ft_str_is_numeric("5856=4687"));
	printf("\n%d", ft_str_is_numeric("585647"));

	return (0);
}
