/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 21:20:46 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_str_is_printable.c"

int	ft_str_is_printable(char *str);

int	main(void)
{

	// printf("%d\n", ft_str_is_alpha(ptr1));
	// printf("%d\n", ft_str_is_alpha(ptr2));
	// printf("%d\n", ft_str_is_alpha(ptr3));
	// printf("%d\n", ft_str_is_alpha(ptr4));
	printf("%d", ft_str_is_printable("¶something wrong¶"));
	printf("\n%d", ft_str_is_printable(""));
	printf("\n%d", ft_str_is_printable("@#this should work *,"));
	printf("\n%d", ft_str_is_printable("\0"));
	printf("\n%d", ft_str_is_printable(" "));
	printf("\n%d", ft_str_is_printable("@#this sho\nuld wo\trk *,"));
	return (0);
}
