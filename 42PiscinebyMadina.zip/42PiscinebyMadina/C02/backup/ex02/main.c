/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 12:06:49 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_str_is_alpha.c"

int	ft_str_is_alpha(char *str);

int	main(void)
{
	char str1[] = "salkdfjv";
	char str2[] = "dfkjs;n6";
	char str3[] = "dsfmkLKMSf";
	char str4[] = "k32r4363:";
	char *ptr1;
	char *ptr2;
	char *ptr3;
	char *ptr4;

	ptr1 = str1;
	ptr2 = str2;
	ptr3 = str3;
	ptr4 = str4;

	// printf("%d\n", ft_str_is_alpha(ptr1));
	// printf("%d\n", ft_str_is_alpha(ptr2));
	// printf("%d\n", ft_str_is_alpha(ptr3));
	// printf("%d\n", ft_str_is_alpha(ptr4));
	printf("%d\n", ft_str_is_alpha(" "));
	printf("%d\n", ft_str_is_alpha("Hello"));
	printf("%d\n", ft_str_is_alpha("Hel?lo"));
	printf("%d\n", ft_str_is_alpha(""));

	return (0);
}
