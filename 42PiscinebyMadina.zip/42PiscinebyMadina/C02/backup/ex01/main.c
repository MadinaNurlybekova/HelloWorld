/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 17:16:03 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 18:42:15 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_strncpy.c"

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int	main(void)
{
	char str1[] = "madina";
	char str2[] = "nurlybekova";
	char *ptr1;
	char *ptr2;

	ptr1 = str1;
	ptr2 = str2;

	//ft_strncpy(str2, str1, 5);
	printf("%s", ft_strncpy(ptr1, ptr2, 6));
	return (0);
}
