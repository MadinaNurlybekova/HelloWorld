/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 21:20:03 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_str_is_uppercase.c"

int	ft_str_is_uppercase(char *str);

int	main(void)
{

	// printf("%d\n", ft_str_is_alpha(ptr1));
	// printf("%d\n", ft_str_is_alpha(ptr2));
	// printf("%d\n", ft_str_is_alpha(ptr3));
	// printf("%d\n", ft_str_is_alpha(ptr4));
	printf("%d", ft_str_is_uppercase("whatsUP"));
	printf("\n%d", ft_str_is_uppercase(""));
	printf("\n%d", ft_str_is_uppercase("HELLO"));
	printf("\n%d", ft_str_is_uppercase("hell o"));
	printf("\n%d", ft_str_is_uppercase("ALKSFNLDKJ"));
	printf("\n%d", ft_str_is_uppercase("hellsfgFDFo"));
	printf("\n%d", ft_str_is_uppercase("ALDK*fd6#"));
	printf("\n%d", ft_str_is_uppercase(" "));
	
	return (0);
}
