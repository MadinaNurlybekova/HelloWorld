/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/18 17:21:18 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 19:58:44 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int ft_strlcpy(char *dest, char *src, unsigned int size)
{
    //unsigned int size_symbols_to_copy;
    unsigned int i;
    unsigned int counter;

    //size_symbols_to_copy = size - 1;
    counter = 0;
    i = 0;
    while (i < size - 1 && src[i] != '\0')
    {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';

    while (src[counter] != '\0')
    {
        counter++;
    }


    return (counter);
}