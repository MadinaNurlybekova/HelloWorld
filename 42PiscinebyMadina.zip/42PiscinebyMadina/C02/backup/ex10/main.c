/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 19:58:36 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_strlcpy.c"

unsigned int ft_strlcpy(char *dest, char *src, unsigned int size);

int	main(void)
{
	/*
	char x_dest[] = "hello";
	char y_src[] = "world";
	printf("string to copy: %s before copy: %s\n", y_src, x_dest);
	printf("len of string: %d string to copy: %s after copy: %s", ft_strlcpy(x_dest, y_src, 3), y_src, x_dest);
	*/
	char string[] = "Hello there, Venus";
    char buffer[19];
    int r;

    r = ft_strlcpy(buffer,string,1);

    printf("Copied '%s' into '%s', length %d\n",
            string,
            buffer,
            r
          );
	
	return (0);
}
