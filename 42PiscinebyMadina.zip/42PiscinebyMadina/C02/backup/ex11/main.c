/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 21:13:34 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_putstr_non_printable.c"

void ft_putstr_non_printable(char *str);

int	main(void)
{
	char nonprint[] = "Coucou\ntu vas bien ?";
	ft_putstr_non_printable(nonprint);
	return (0);
}
