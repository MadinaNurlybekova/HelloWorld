/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 18:39:41 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/18 12:22:01 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_str_is_lowercase.c"

int	ft_str_is_lowercase(char *str);

int	main(void)
{

	// printf("%d\n", ft_str_is_alpha(ptr1));
	// printf("%d\n", ft_str_is_alpha(ptr2));
	// printf("%d\n", ft_str_is_alpha(ptr3));
	// printf("%d\n", ft_str_is_alpha(ptr4));
	printf("%d", ft_str_is_lowercase("whatsUP"));
	printf("\n%d", ft_str_is_lowercase(""));
	printf("\n%d", ft_str_is_lowercase("hello"));
	printf("\n%d", ft_str_is_lowercase("hell o"));
	printf("\n%d", ft_str_is_lowercase("ALKSFNLDKJ"));
	printf("\n%d", ft_str_is_lowercase("hellsfgFDFo"));
	printf("\n%d", ft_str_is_lowercase("nurlybekova"));
	
	return (0);
}
