/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/17 17:16:03 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/17 18:26:28 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_strcpy.c"

char	*ft_strcpy(char *dest, char *src);

int	main(void)
{
	char str1[] = "asdsada";
	char str2[] = "Holddks";
	char *ptr1;
	char *ptr2;

	ptr1 = str1;
	ptr2 = str2;


	ft_strcpy(ptr2, ptr1);
	printf("%s", ft_strcpy(ptr2, ptr1));
	return (0);
}
