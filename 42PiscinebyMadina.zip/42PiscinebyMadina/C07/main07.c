/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main07.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 12:06:47 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/30 11:25:54 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
// #include "ex00/ft_strdup.c"
// #include "ex01/ft_range.c"
// #include "ex02/ft_ultimate_range.c"
// #include "ex03/ft_strjoin.c"
// #include "ex04/ft_convert_base.c"
// #include "ex04/ft_convert_base2.c"
 #include "ex05/ft_split.c"

int main(void)
{
    // ex00
//  ==============================================
    // char src[17] = "MadinaNurlybekova";
    // char *ptr;
    // ptr = ft_strdup(src);
    // printf("%s", ptr);
    // free (ptr);

    // ex01
// ==============================================  
    // int min;
    // int max;
    // int *arr;
    // int i = 0;
    // int size;
    // min = 3;
    // max = 25;
    // size = max-min;
    // arr = ft_range(min, max);
    
    // if (size <= 0)
    // {
    //     printf("%p", arr);
    // }
    // else
    // {
    // while (i < size)
    //     {
    //         printf("%d, ", arr[i]);
    //         i++;
    //     }
    // }
    // free(arr);
    
    // ex02
// ==============================================
    // int *range;
    // int j = 0;
    // int size;

    // size = ft_ultimate_range(&range, 15, 25);
    // printf("Size of array is %d\n", size);
    // while (j < size)
    // {
    //     printf("%d, ", range[j]);
    //     j++;
    // }
    // free(range);

    // ex03
// ==============================================
    // char *strs[6];
    
    // strs[0] = "Hello";
    // strs[1] = "my";
    // strs[2] = "name";
    // strs[3] = "is";
    // strs[4] = "C";
    // strs[5] = "language";

    // printf("%s", ft_strjoin(0, strs, "_"));


    // ex04
// ==============================================

    // printf("%s\n", ft_convert_base("   +---09", "01234567", "0123456789ABCDEF"));
    // printf("%s\n", ft_convert_base(" ---+-+pyb567", "poneyvif", "01234567"));
    // printf("%s\n", ft_convert_base(" --+-+-7FFFFFFF-C567", "0123456789ABCDEF", "0123456789"));
    // printf("%s\n", ft_convert_base("       --++---10000000000000000000000000000000", "01", "0123456789ABCDEF"));
    // printf("%s\n", ft_convert_base("       --++---10000000000000000000000000000000", "01", "0123456789"));
    // printf("%s\n", ft_convert_base("   +---569", "01234656789ABCDEF", "01234567"));
    // printf("%s\n", ft_convert_base("--01234", "01234567899", "01"));

    // ex05
// ==============================================

    char s[] = "To be, or not to be, that is the question.";
    char charset[] = " t,";
 	int		index;
	char	**split;
	
	split = ft_split(s, charset);
	index = 0;
	while (split[index])
	{
		printf("%s\n", split[index]);
		index++;
	}

    return 0;
}
