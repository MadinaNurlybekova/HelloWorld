/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 13:24:17 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 13:40:39 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	calculcate_final_len(int dec_num, char *base_to)
{
	int	len_base;
	int	counter;

	counter = 0;
	len_base = ft_strlen(base_to);
	while (dec_num != 0)
	{
		dec_num = dec_num / len_base;
		counter++;
	}
	return (counter);
}

void	pos_num_convert(long nbr_long, char *base_to, char *final_result, int i)
{
	int	len_base;
	int	final_length;

	final_length = calculcate_final_len(nbr_long, base_to);
	len_base = ft_strlen(base_to);
	if (i == 0)
	{
		while (nbr_long > 0)
		{
			final_result[final_length - 1] = base_to[nbr_long % len_base];
			nbr_long = nbr_long / len_base;
			final_length--;
		}
	}
	if (i == 1)
	{
		while (final_length != 0)
		{
			final_result[final_length] = base_to[nbr_long % len_base];
			nbr_long = nbr_long / len_base;
			final_length--;
		}
	}
}

void	ft_putnbr_base_to(int dec_num, char *base_to, char *final_result)
{
	long	nbr_long;
	int		i;

	nbr_long = dec_num;
	if (nbr_long == 0)
	{
		final_result[0] = base_to[nbr_long];
	}
	else if (nbr_long > 0)
	{
		i = 0;
		pos_num_convert(nbr_long, base_to, final_result, i);
	}
	else
	{
		final_result[0] = '-';
		nbr_long = nbr_long * (-1);
		i = 1;
		pos_num_convert(nbr_long, base_to, final_result, i);
	}
}
