/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 13:52:52 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/26 20:21:24 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strchr(char c, char *charset)
{
	int	i;

	i = 0;
	while (charset[i] != '\0')
	{
		if (charset[i] == c)
		{
			return (1);
		}
		i++;
	}
	if (c == '\0')
		return (1);
	return (0);
}

int	ft_count_words(char *str, char *charset)
{
	int	counter;
	int	i;

	counter = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if (ft_strchr(str[i + 1], charset) == 1
			&& ft_strchr(str[i], charset) == 0)
		{
			counter++;
		}
		i++;
	}
	return (counter);
}

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

void	do_split(char **array, char *str, char *charset, char *buffer)
{
	int	array_index;
	int	j;
	int	i;

	i = 0;
	array_index = -1;
	while (str[i] != '\0')
	{
		if (ft_strchr(str[i], charset) == 1)
			i++;
		else
		{
			j = -1;
			while (j++, ft_strchr(str[i + j], charset) == 0)
				buffer[j] = str[i + j];
			if (array_index++, j > 0)
			{
				buffer[j] = '\0';
				array[array_index] = (char *)malloc(sizeof(char) * j + 1);
				ft_strcpy(array[array_index], buffer);
				i += j;
			}
		}
	}
}

char	**ft_split(char *str, char *charset)
{
	char	**array;
	char	buffer[16384];

	array = malloc(sizeof(char *) * ft_count_words(str, charset) + 1);
	do_split(array, str, charset, buffer);
	array[ft_count_words(str, charset)] = 0;
	return (array);
}
