/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 13:24:15 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 11:17:39 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

void	ft_putnbr_base_to(int dec_num, char *base_to, char *final_result);
int		calculcate_final_len(int dec_num, char *base_to);

int	base_error_check(char *base)
{
	int	i;
	int	j;

	i = 0;
	if (base[0] == '\0' || base[1] == '\0')
		return (0);
	while (base[i] != '\0')
	{
		if ((base[i] >= 9 && base[i] <= 13) || base[i] == 32
			|| base[i] == 43 || base[i] == 45)
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (i);
}

int	ft_isspace(int i, char *str)
{
	while (str[i] == '\f' || str[i] == '\n' || str[i] == '\r'
		|| str[i] == '\t' || str[i] == '\v' || str[i] == ' ')
	{
		i++;
	}
	return (i);
}

int	str_check_and_convert(char *str, char *base, int i)
{
	int	j;
	int	counter;
	int	nbr;

	nbr = 0;
	while (str[i] != '\0')
	{
		j = 0;
		counter = 0;
		while (j < base_error_check(base))
		{
			if (str[i] == base[j])
			{
				nbr = (nbr * base_error_check(base)) + j;
				counter++;
			}
			j++;
		}
		if (counter == 0)
			break ;
		i++;
	}
	return (nbr);
}

int	ft_atoi_base_from(char *str, char *base)
{
	int	i;
	int	sign;
	int	result;

	i = 0;
	sign = 1;
	i = ft_isspace(i, str);
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	result = str_check_and_convert(str, base, i);
	return (result * sign);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int		dec_num;
	int		final_length;
	char	*final_result;

	if (base_error_check(base_from) > 0 || base_error_check(base_to) > 0)
	{
		dec_num = ft_atoi_base_from(nbr, base_from);
		final_length = calculcate_final_len(dec_num, base_to);
		final_result = (char *)malloc(sizeof(char) * final_length + 2);
		if (!final_result)
			return (0);
		if (dec_num == 0)
		{
			final_result[0] = base_to[dec_num];
			return (final_result);
		}
		ft_putnbr_base_to(dec_num, base_to, final_result);
		if (dec_num < 0)
			final_result[final_length + 1] = '\0';
		else
			final_result[final_length] = '\0';
		return (final_result);
	}
	else
		return (0);
}
