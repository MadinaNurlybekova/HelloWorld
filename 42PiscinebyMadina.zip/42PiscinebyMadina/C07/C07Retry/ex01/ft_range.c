/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 14:08:21 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 10:55:38 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*duplicate;
	int	i;

	if (min >= max)
		return (0);
	duplicate = (int *)malloc(sizeof(*duplicate) * (max - min));
	if (duplicate == NULL)
		return (0);
	i = 0;
	while (i < (max - min))
	{
		duplicate[i] = min + i;
		i++;
	}
	return (duplicate);
}
