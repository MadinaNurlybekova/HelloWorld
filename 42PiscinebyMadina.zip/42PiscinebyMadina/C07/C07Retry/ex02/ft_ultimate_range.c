/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 14:52:28 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 11:00:55 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*duplicate;
	int	i;

	if (min >= max)
	{
		*range = 0;
		return (0);
	}
	duplicate = (int *)malloc(sizeof(*duplicate) * (max - min));
	if (duplicate == NULL)
		return (-1);
	i = 0;
	while (min < max)
	{
		duplicate[i] = min;
		min ++;
		i++;
	}
	*range = duplicate;
	return (i);
}
