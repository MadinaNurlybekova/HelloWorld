/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 19:58:34 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 10:57:42 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

int	ft_strlen(char *str)
{
	int	counter;

	counter = 0;
	while (str[counter] != '\0')
	{
		counter++;
	}
	return (counter);
}

char	*ft_strcat(char *dest, char *src)
{
	int	len_dst;
	int	i;

	len_dst = ft_strlen(dest);
	i = 0;
	while (src[i] != '\0')
	{
		dest[len_dst + i] = src[i];
		i++;
	}
	dest[len_dst + i] = '\0';
	return (dest);
}

int	strs_full_len(int size, char **strs, char *sep)
{
	int		full_len;
	int		i;

	i = 0;
	full_len = ft_strlen(sep) * (size - 1);
	while (i < size)
	{
		full_len += ft_strlen(strs[i]);
		i++;
	}
	return (full_len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	char	*dup_str;

	i = 0;
	if (size == 0)
	{
		dup_str = malloc(sizeof(char));
		*dup_str = 0;
		return (dup_str);
	}
	dup_str = (char *)malloc(sizeof(char)
			* strs_full_len(size, strs, sep) + 1);
	if (dup_str == NULL)
		return (0);
	ft_strcpy(dup_str, strs[0]);
	i = 1;
	while (i < size)
	{
		ft_strcat(dup_str, sep);
		ft_strcat(dup_str, strs[i]);
		i++;
	}
	ft_strcat(dup_str, "\0");
	return (dup_str);
}
