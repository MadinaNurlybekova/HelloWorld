/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 12:05:38 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 09:24:44 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	int			i;
	char		*duplicate;

	i = 0;
	while (src[i] != '\0')
		i++;
	duplicate = malloc(sizeof(char *) * (i + 1));
	if (duplicate == NULL)
		return (0);
	else
	{
		i = 0;
		while (src[i] != '\0')
		{
			duplicate[i] = src[i];
			i++;
		}
		duplicate[i] = '\0';
	}
	return (duplicate);
}
