/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Square.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/31 15:02:52 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/31 21:58:11 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include "create_int_square.c"

int count_rows(char *file)
{
    int fd;
    int count;
    char    c;

    fd = open(file, O_RDONLY);
    count = 0;
	while (read(fd, &c, 1) != 0)
	{
        if (c == '\n')
            count++;
	}
	close(fd);
    if (count == 0)
        return (0);
    return (count - 1);
}

int count_elem(char *file)
{
    int fd;
    int elem_count;
    int max = 0;
    int lines;
    char    c;

    fd = open(file, O_RDONLY);
    lines = 0;
    elem_count = 0;
    // printf("row number %d\n", lines);
    // printf("elem_count number %d\n", elem_count);
    while (read(fd, &c, 1) != 0)
	{
        if (c == '\n')
            lines++;
        if (lines == 1)
            break;
	}
    // printf("row number %d\n", lines);
    // printf("elem_count number %d\n", elem_count);
    while (read(fd, &c, 1) != 0 && c != '\n')
    {
        elem_count++;
    }
    // printf("row number %d\n", lines);
    // printf("elem_count number %d\n", elem_count);
    lines++;
    max = elem_count;
    while (lines <= count_rows(file))
    {
        elem_count = 0;
        while (read(fd, &c, 1) != 0 && c != '\n')
            elem_count++;
        // printf("row number %d\n", lines);
        // printf("elem_count number %d\n", elem_count);
        if (elem_count != max)
                return (0);
        lines++;
    }
	close(fd);
    return (elem_count);
} 

int main(int argc, char **argv)
{   
    int i;
    int fd;
    int rows;
    int elem;
    int **square_1;
    int **square_2;
    i = 1;
    while (i < argc)
    {
        rows = count_rows(argv[i]);
        elem = count_elem(argv[i]);
        fd = open(argv[i], O_RDONLY);
        square_1 = create_int_square(fd, rows+1, elem+1);
        close(fd);
        
        fd = open(argv[i], O_RDONLY);
        square_2 = create_int_square(fd, rows+1, elem+1);
        close(fd);

        int bsq[] = {1, 6, 6};
        char symbols[] = ".ox";
        final_square(square_1, bsq, symbols, rows+1, elem+1);

        i++;
    }
    return (0);
}
