/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 12:05:38 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 09:24:44 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	print_array(int **ar, int rows, int elem)
{

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < elem; j++)
		{
		    printf("%d", ar[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

int **add_ones(int **our_square, int fd, int rows)
{
	int lines;
	int elem_count;
	char    c;
	
	lines = 0;
	elem_count = 0;
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
		    lines++;
		if (lines == 1)
		    break;
	}
	while (lines <= rows)
	{
		elem_count = 0;
        	while (read(fd, &c, 1) != '\0')
       		{
       			elem_count++;
       			if (c == 'o')
       			{
       				our_square[lines][elem_count] = 1;
       			}
       			if (c == '\n')
       				break;
        	}
        	lines++;
	}
	return (our_square);
}

int	**create_int_square(int fd, int rows, int elem)
{
	int row_i;
	int el_i;
	int **square;
	
	row_i = 0;
	el_i = 0;
	square = malloc(sizeof(int*)*rows);
	while (row_i < rows)
	{
		square[row_i] = malloc(sizeof(int*) * elem);
		row_i++;
	}
	row_i = 0;
	while (row_i < rows)
	{
		while (el_i < elem)
		{
			if (row_i == 0 || el_i == 0)
				square[row_i][el_i] = 0;
			el_i++;
		}
		row_i++;
	}
	
	add_ones(square, fd, rows); 
	print_array(square, rows, elem);
	return (square);
}

int is_in_square(int start_i, int start_j, int len, int x, int y)
{
	if ((x >= start_i && x <= start_i + len) 
		&& (y >= start_j && y <= start_j + len))
		return (1);
	return (0);
}

void	final_square(int **square_1, int *bsq, char *symbols, int rows, int elem)
{
	int i;
	int j;

	i = 1;
	j = 1;
	while (i < rows)
	{
		j = 1;
		while (j < elem)
		{
			if (square_1[i][j] == 1)
				write(1, &symbols[1], 1);
			else if (is_in_square(bsq[0], bsq[1], bsq[2], i, j))
				write(1, &symbols[2], 1);
			else
				write(1, &symbols[0], 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}











































