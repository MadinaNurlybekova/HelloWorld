/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Error_check.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 17:39:09 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 16:49:06 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	error_check_main(char *file)
{
	if (open(file, O_RDONLY) == -1)
		return (0);
	if ((count_rows_err(file)) == 0)
		return (0);
	if ((count_elem_err(file)) == 0)
		return (0);
	if ((number_character_check(file)) == 0)
		return (0);
	if ((printable_character_check(file)) == 0)
		return (0);
	if ((identical_character_check(file)) == 0)
		return (0);
	if ((check_if_right_character(file)) == 0)
		return (0);
	if (get_row_nbr(file) != count_rows_err(file))
		return (0);
	return (1);
}
