/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/02 18:54:47 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 18:59:56 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	main_two(void)
{
	if (error_check_main("test") == 0)
		write(2, "map error\n", 11);
	else
		square_main("test");
	write(1, "\n", 1);
}

int	main(int argc, char **argv)
{
	int		i;
	int		file;

	if (argc == 1)
	{
		file = open("test", O_RDONLY | O_WRONLY | O_TRUNC);
		get_std_input(file);
		close(file);
		write(1, "\n", 1);
		main_two();
	}
	if (argc > 1)
	{
		i = 0;
		while (++i < argc)
		{
			if (error_check_main(argv[i]) == 0)
				write(2, "MAP ERROR\n", 11);
			else
				square_main(argv[i]);
			write(1, "\n", 1);
		}
	}
	return (0);
}
