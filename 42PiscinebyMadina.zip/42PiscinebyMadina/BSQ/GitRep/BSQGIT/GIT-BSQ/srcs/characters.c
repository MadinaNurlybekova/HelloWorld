/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   characters.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 14:35:46 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 16:56:36 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	*ft_strcpy(char *dest, char *file, int len)
{
	int		i;
	int		j;
	int		fd;
	char	c;

	i = 0;
	j = 0;
	fd = open(file, O_RDONLY);
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			break ;
		if (j >= len - 3)
		{
			dest[i] = c;
			i++;
		}
		j++;
	}
	dest[i] = '\0';
	close(fd);
	return (dest);
}

char	*get_symbols(char *file)
{
	int		elem_count;
	int		fd;
	char	c;
	char	*symbols;

	elem_count = 0;
	fd = open(file, O_RDONLY);
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			break ;
		elem_count++;
	}
	symbols = malloc(sizeof(char) * elem_count + 1);
	ft_strcpy(symbols, file, elem_count);
	close(fd);
	return (symbols);
}
