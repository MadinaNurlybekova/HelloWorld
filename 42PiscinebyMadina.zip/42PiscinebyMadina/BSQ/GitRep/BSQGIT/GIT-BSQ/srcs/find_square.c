/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_square.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vzhadan <vzhadan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 12:35:34 by vzhadan           #+#    #+#             */
/*   Updated: 2022/11/02 18:05:47 by vzhadan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

void	modify_ar(int **ar, int length, int height)
{
	int	i;
	int	j;

	i = 1;
	j = 1;
	while (i < length)
	{
		while (j < height)
		{
			if (ar[i][j] > 0)
				ar[i][j] += ar[i - 1][j] + ar[i][j - 1] - ar[i - 1][j - 1];
			else
				ar[i][j] = ar[i - 1][j] + ar[i][j - 1] - ar[i - 1][j - 1];
			j++;
		}
		j = 1;
		i++;
	}
}

int	for_normiette1(int **ar, int i, int j, int len)
{
	int	n1;
	int	n2;

	n1 = ar[i - 1][j + len];
	n2 = ar[i + len][j - 1];
	if (ar[i + len][j + len] - n1 - n2 + ar[i - 1][j - 1] <= 0)
		return (1);
	return (0);
}

void	for_normiette2(int i, int j, int len, int *answ)
{
	if (len > answ[2])
	{
		answ[0] = i;
		answ[1] = j;
		answ[2] = len;
	}
}

int	*find_square(int **ar, int length, int height)
{
	int	i;
	int	j;
	int	len;
	int	*answ;

	answ = (int *) malloc(3 * sizeof(int));
	modify_ar(ar, length, height);
	len = 0;
	while (len <= height)
	{
		i = 1;
		while (i < length)
		{
			j = 0;
			while (++j < height)
			{	
				if ((i + len) < length && (j + len) < height)
					if (for_normiette1(ar, i, j, len))
						for_normiette2(i, j, len, answ);
			}	
			i++;
		}
		len++;
	}
	return (answ);
}
