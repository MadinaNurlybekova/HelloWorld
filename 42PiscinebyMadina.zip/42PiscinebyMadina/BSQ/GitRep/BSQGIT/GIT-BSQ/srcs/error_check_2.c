/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_check_2.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 21:21:52 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 16:52:57 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

char	*ft_strcpy_nbr(char *dest, char *file, int len)
{
	int		i;
	int		j;
	int		fd;
	char	c;

	i = 0;
	j = 0;
	fd = open(file, O_RDONLY);
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			break ;
		if (j < len)
		{
			dest[i] = c;
			i++;
		}
		j++;
	}
	dest[i] = '\0';
	close(fd);
	return (dest);
}

int	get_row_nbr(char *file)
{
	int		i;
	int		fd;
	char	c;
	char	*row_nbr;
	int		nbr;

	i = 0;
	fd = open(file, O_RDONLY);
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			break ;
		i++;
	}
	row_nbr = malloc(sizeof(char) * i - 3);
	close(fd);
	ft_strcpy_nbr(row_nbr, file, i - 3);
	nbr = 0;
	i = 0;
	while (row_nbr[i] != '\0')
	{
		nbr = nbr * 10 + (row_nbr[i] - '0');
		i++;
	}
	return (nbr);
}

int	count_rows_err(char *file)
{
	int		fd;
	int		count;
	char	c;

	fd = open(file, O_RDONLY);
	count = 0;
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			count++;
	}
	close(fd);
	if (count == 0 || count == 1)
		return (0);
	else
		return (count - 1);
}

int	skip_first_row_err(int fd)
{
	int		lines;
	char	c;

	lines = 0;
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			lines++;
		if (lines == 1)
			break ;
	}
	return (lines);
}

int	count_elem_err(char *file)
{
	int		fd;
	int		elem_count;
	int		max;
	int		lines;
	char	c;

	fd = open(file, O_RDONLY);
	elem_count = 0;
	lines = skip_first_row_err(fd);
	while (read(fd, &c, 1) != 0 && c != '\n')
		elem_count++;
	lines++;
	max = elem_count;
	while (lines <= count_rows_err(file))
	{
		elem_count = 0;
		while (read(fd, &c, 1) != 0 && c != '\n')
			elem_count++;
		if (elem_count != max)
			return (0);
		lines++;
	}
	close(fd);
	return (elem_count);
}
