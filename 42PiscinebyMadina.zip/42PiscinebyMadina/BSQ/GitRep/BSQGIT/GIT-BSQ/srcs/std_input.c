/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tmp.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vzhadan <vzhadan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/02 18:48:15 by vzhadan           #+#    #+#             */
/*   Updated: 2022/11/02 18:50:05 by vzhadan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

#define STR_LEN 27

void	norminette3(int num_of_lines, int file, char c)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < num_of_lines)
	{
		while (j <= STR_LEN)
		{
			read(0, &c, 1);
			write(file, &c, 1);
			if (c == '\n')
				break ;
			j++;
		}
		i++;
		j = 0;
	}
}

void	get_std_input(int file)
{
	char	buffer1[10];
	int		i;
	int		j;
	char	c;
	int		num_of_lines;	

	num_of_lines = 0;
	write(1, "There is no input files, so input map\n", 39);
	i = 0;
	while (read(0, &c, 1) != 0)
	{
		buffer1[i] = c;
		i++;
		if (c == '\n')
			break ;
	}
	j = 0;
	while (j < i - 4)
	{
		num_of_lines = 10 * num_of_lines + buffer1[j] - '0';
		j++;
	}
	write(file, &buffer1, i);
	norminette3(num_of_lines, file, c);
}
