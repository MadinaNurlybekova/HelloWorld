/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_int_square.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/24 12:05:38 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 16:55:34 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	skip_first_row_add_ones(int fd)
{
	int		lines;
	char	c;

	lines = 0;
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			lines++;
		if (lines == 1)
			break ;
	}
	return (lines);
}

int	**add_ones(int **our_square, int fd, int rows, char *symbols)
{
	int		lines;
	int		elem_count;
	char	c;

	lines = 0;
	elem_count = 0;
	lines = skip_first_row_add_ones(fd);
	while (lines <= rows)
	{
		elem_count = 0;
		while (read(fd, &c, 1) != '\0')
		{
			elem_count++;
			if (c == symbols[1])
			{
				our_square[lines][elem_count] = 1;
			}
			if (c == '\n')
				break ;
		}
		lines++;
	}
	return (our_square);
}

int	**create_int_square(int fd, char *symbols, int rows, int elem)
{
	int	row_i;
	int	el_i;
	int	**square;

	row_i = 0;
	el_i = 0;
	square = malloc(sizeof(int *) * rows);
	while (row_i < rows)
	{
		square[row_i] = malloc(sizeof(int *) * elem);
		row_i++;
	}
	row_i = 0;
	while (row_i < rows)
	{
		while (el_i < elem)
		{
			if (row_i == 0 || el_i == 0)
				square[row_i][el_i] = 0;
			el_i++;
		}
		row_i++;
	}
	add_ones(square, fd, rows, symbols);
	return (square);
}

int	is_in_square(int *bsq, int x, int y)
{
	if ((x >= bsq[0] && x <= bsq[0] + bsq[2])
		&& (y >= bsq[1] && y <= bsq[1] + bsq[2]))
		return (1);
	return (0);
}

void	final_square(int **square_1, int *bsq, char *symbols, int *rows_elem)
{
	int	i;
	int	j;

	i = 1;
	j = 1;
	while (i < rows_elem[0] + 1)
	{
		j = 1;
		while (j < rows_elem[1] + 1)
		{
			if (square_1[i][j] == 1)
				write(1, &symbols[1], 1);
			else if (is_in_square(bsq, i, j))
				write(1, &symbols[2], 1);
			else
				write(1, &symbols[0], 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}
