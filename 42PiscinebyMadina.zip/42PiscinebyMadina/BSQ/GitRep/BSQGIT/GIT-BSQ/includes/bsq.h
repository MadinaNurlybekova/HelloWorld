/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 22:01:46 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 19:06:20 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BSQ_H
# define BSQ_H

# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>

int		error_check_main(char *file);
char	*ft_strcpy(char *dest, char *file, int len);
char	*get_symbols(char *file);
int		number_character_check(char *file);
int		printable_character_check(char *file);
int		identical_character_check(char *file);
int		check_if_in_symbols(char c, char *file);
int		check_if_right_character(char *file);
char	*ft_strcpy_nbr(char *dest, char *file, int len);
int		get_row_nbr(char *file);
int		count_rows_err(char *file);
int		count_elem_err(char *file);
int		**add_ones(int **our_square, int fd, int rows, char *symbols);
int		**create_int_square(int fd, char *symbols, int rows, int elem);
int		is_in_square(int *bsq, int x, int y);
void	final_square(int **square_1, int *bsq, char *symbols, int *rows_elem);
void	modify_ar(int **ar, int length, int height);
int		*find_square(int **ar, int length, int height);
void	square_main(char *file);
int		count_elem(char *file);
int		count_rows(char *file);
void	get_std_input(int file);
void	print_array(int **ar, int rows, int elem);
int		skip_first_row_err(int fd);
int		skip_first_row(int fd);
int		skip_first_row_add_ones(int fd);
void	main_two(void);

#endif
