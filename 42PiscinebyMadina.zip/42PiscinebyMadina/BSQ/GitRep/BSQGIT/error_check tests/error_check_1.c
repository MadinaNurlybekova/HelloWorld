/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_check_1.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 21:17:29 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/01 22:05:32 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <sys/types.h>
// #include <sys/stat.h>
// #include <fcntl.h>
// #include <unistd.h>
// #include <stdio.h>
// #include "characters.c"
#include "bsq.h"
// //====================================================
int number_character_check(char *file)
{
    char *symbols;
    int i;
    char c;
    int fd;
    
    i = 0;
    fd = open(file, O_RDONLY);
    while (read(fd, &c, 1) != 0)
	{
        if (c == '\n')
            break;
        i++;
	}
    close(fd);
    if (i <= 3)
    {
        return (0);
    }
    else
        return (1);
}

// // //====================================================

int printable_character_check(char *file)
{
    char *symbols;
    int i;
    i = 0;
    symbols = get_symbols(file);
    while (symbols[i] != '\0')
    {
        if (symbols[i] >= 0 && symbols[i] <= 31)
            return (0);
        i++;
    }
    return (1);
}

// //=====================================================

int identical_character_check(char *file) 
{
    char *symbols;
    int i;
    int j;
    
    i = 0;
    symbols = get_symbols(file);
    while (symbols[i] != '\0')
    {
        j = i + 1;
        while (symbols[j] != '\0')
        {
            if (symbols[i] == symbols[j])
                return (0);
            j++;
        }
        i++;
    }
    return (1);
}

// //=====================================================

int check_if_in_symbols(char c, char *file)
{
    char *symbols;
    int i;
    
    i = 0;
    symbols = get_symbols(file);
    while (i != 2)
	{
		if (symbols[i] == c)
			return (1);
		i++;
	}
    return (0);
}

int check_if_right_character(char *file) 
{
    int fd;
    int lines;
    char c;
    
    fd = open(file, O_RDONLY);
    lines = 0;
    while (read(fd, &c, 1) != 0)
	{
        if (c == '\n')
            lines++;
        if (lines == 1)
            break;
	}
    while (read(fd, &c, 1) != 0)
    {
        if (c != '\n')
        {
            if ((check_if_in_symbols(c, file)) == 0) 
            {
                close(fd);
                return (0);
            }
        }
    }
    close(fd);
    return (1);
}
