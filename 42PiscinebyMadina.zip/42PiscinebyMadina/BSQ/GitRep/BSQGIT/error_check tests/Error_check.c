/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Error_check.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 17:39:09 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/01 22:24:44 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int error_check_main(char *file)
{
    if ((count_rows_err(file)) == 0) //There’s at least one line of at least one box.
        return (0);
    if ((count_elem_err(file)) == 0) //All lines must have the same length.
        return (0);
    if ((number_character_check(file)) == 0)
        return (0);
    if ((printable_character_check(file)) == 0) //The characters can be any printable character, even numbers. AND //The map is invalid if a character is missing from the first line
        return (0);
    if ((identical_character_check(file)) == 0) //two characters (of empty, full and obstacle) are identical
        return (0);
    if ((check_if_right_character(file)) == 0) //The characters on the map can only be those introduced in the first line.
        return (0);
    if (get_row_nbr(file) != count_rows_err(file)) //Check if amount of rows is the same as mentioned in the file
        return (0);
    return (1);
}

int main(int argc, char **argv)
{
    (void) argc;
    if (error_check_main(argv[1]) == 0)
        write(2, "map error\n", 10);
    else 
        write(2, "No error", 8);
    return (0);
}
