/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Square.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/31 15:02:52 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/01 16:46:26 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include "create_int_square.c"
#include "find_square.c"
#include "characters.c"

int count_rows(char *file)
{
    int fd;
    int count;
    char    c;

    fd = open(file, O_RDONLY);
    count = 0;
	while (read(fd, &c, 1) != 0)
	{
        if (c == '\n')
            count++;
	}
	close(fd);
    if (count == 0)
        return (0);
    return (count - 1);
}

int count_elem(char *file)
{
    int fd;
    int elem_count;
    int max = 0;
    int lines;
    char    c;

    fd = open(file, O_RDONLY);
    lines = 0;
    elem_count = 0;
    while (read(fd, &c, 1) != 0)
	{
        if (c == '\n')
            lines++;
        if (lines == 1)
            break;
	}
    while (read(fd, &c, 1) != 0 && c != '\n')
        elem_count++;
    lines++;
    max = elem_count;
    while (lines <= count_rows(file))
    {
        elem_count = 0;
        while (read(fd, &c, 1) != 0 && c != '\n')
            elem_count++;
        if (elem_count != max)
                return (0);
        lines++;
    }
	close(fd);
    return (elem_count);
} 

int main(int argc, char **argv)
{   
    int i;
    int fd;
    int **square_1;
    int **square_2;
    char *symbols;
    int rows_elem[2];
    
    i = 1;
    while (i < argc)
    {
        rows_elem[0] = count_rows(argv[i]);
        rows_elem[1] = count_elem(argv[i]);
        symbols = get_symbols(argv[1]);
        fd = open(argv[i], O_RDONLY);
        square_1 = create_int_square(fd, symbols, rows_elem[0] + 1, rows_elem[1]+1);
        close(fd);
        
        fd = open(argv[i], O_RDONLY);
        square_2 = create_int_square(fd, symbols, rows_elem[0]+1, rows_elem[1]+1);
        close(fd);

        int *bsq = find_square(square_2, rows_elem[0] + 1 , rows_elem[1] + 1);
        final_square(square_1, bsq, symbols, rows_elem);

        i++;
    }
    return (0);
}
