// #include <unistd.h>
// #include <stdlib.h>
// #include <stdio.h>
// #include <fcntl.h>
#include "bsq.h"

#define STR_LEN 27

void get_std_input(int file)
{
	char	buffer1[10];
	int		i;
	int		j;
	char	c;
	int		num_of_lines = 0;	
	
	write(1, "There is no input files, so input map\n", 39);
	i = 0;
	while (read(0, &c, 1) != 0)
	{
		buffer1[i] = c;
		i++;	
		if (c == '\n')
			break ; 
	}
	j = 0;
	while (j < i - 4)
	{
		num_of_lines = 10 * num_of_lines + buffer1[j] - '0';
		j++;
	}
	printf("%d\n", num_of_lines);
	write(file, &buffer1, i);
	i = 0;
	j = 0;
	while (i < num_of_lines)
	{
		while (j <= STR_LEN)
		{
			read(0, &c, 1);
			write(file, &c, 1);
			if (c == '\n')
				break ;
			j++;
			
		}
		i++;
		j = 0;
	}
	// while (j <= STR_LEN)
	// {
	// 	read(0, &c, 1);
	// 	if (c == '\n')
	// 		break ;
	// 	write(file, &c, 1);
	// 	j++;
	// }
}
