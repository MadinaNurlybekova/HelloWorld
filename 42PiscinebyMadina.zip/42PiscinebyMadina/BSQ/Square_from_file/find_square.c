/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_square.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vzhadan <vzhadan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/02 16:31:26 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 17:52:15 by vzhadan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void modify_ar(int **ar, int length, int height)
{
	int i;
	int j;
	i = 1;
	j = 1;
	while (i < length)
	{
		while (j < height)
		{
			if (ar[i][j] > 0)
				ar[i][j] = ar[i][j] + ar[i-1][j] + ar[i][j-1] - ar[i-1][j-1];
			else 
				ar[i][j] = ar[i-1][j] + ar[i][j-1] - ar[i-1][j-1];
			j++;
		}
		j = 1;
		i++;
	}
}

int *find_square(int **ar, int length, int height)
{
	int i;
	int j;
	int len;
	int *answ;

	answ = (int *) malloc(3 * sizeof(int));
	modify_ar(ar, length, height);
	len = 0;
	i = 1;
	j = 1;
	answ[0] = i;
	answ[1] = j;
	answ[2] = len;
	while (len <= height)
	{
		
		while (i < length)
		{
			while (j < height)
			{
				if ((i + len) < length && (j + len) < height)
				{
					if ((ar[i + len][j + len] - ar[i-1][j + len] - ar[i + len][j-1] + ar[i-1][j-1]) <= 0)
					{
						// printf("i = %d, j = %d, len = %d\n", i, j, len);
						if (len > answ[2])
						{
							answ[0] = i;
							answ[1] = j;
							answ[2] = len;
						}
					}
				}
				j++;
			}
			j = 1;
			i++;
		}
		i = 1;
		len++;
	}
	// printf(" max len = %d\nj = %d\ni = %d\n", answ[2], answ[1], answ[0]);
	return (answ);
}

