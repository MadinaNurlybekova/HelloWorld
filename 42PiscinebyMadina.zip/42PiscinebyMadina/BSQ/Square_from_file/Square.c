/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Square.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/31 15:02:52 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 18:28:10 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	count_rows(char *file)
{
	int		fd;
	int		count;
	char	c;

	fd = open(file, O_RDONLY);
	count = 0;
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			count++;
	}
	close(fd);
	if (count == 0)
		return (0);
	return (count - 1);
}

int	skip_first_row(int fd)
{
	int		lines;
	char	c;

	lines = 0;
	while (read(fd, &c, 1) != 0)
	{
		if (c == '\n')
			lines++;
		if (lines == 1)
			break ;
	}
	return (lines);
}

int	count_elem(char *file)
{
	int		fd;
	int		elem_count;
	int		max;
	int		lines;
	char	c;

	fd = open(file, O_RDONLY);
	elem_count = 0;
	lines = skip_first_row(fd);
	while (read(fd, &c, 1) != 0 && c != '\n')
		elem_count++;
	lines++;
	max = elem_count;
	while (lines <= count_rows(file))
	{
		elem_count = 0;
		while (read(fd, &c, 1) != 0 && c != '\n')
			elem_count++;
		if (elem_count != max)
			return (0);
		lines++;
	}
	close(fd);
	return (elem_count);
}

void	square_main(char *file)
{
	int		fd;
	int		**square_1;
	int		**square_2;
	char	*symbols;
	int		*bsq;
	int		rows_elem[2];

	rows_elem[0] = count_rows(file);
	rows_elem[1] = count_elem(file);
	symbols = get_symbols(file);
	fd = open(file, O_RDONLY);
	square_1 = create_int_square(fd, symbols, rows_elem[0] + 1, rows_elem[1] + 1);
	close(fd);
	fd = open(file, O_RDONLY);
	square_2 = create_int_square(fd, symbols, rows_elem[0] + 1, rows_elem[1] + 1);
	close(fd);
	bsq = find_square(square_2, rows_elem[0] + 1 , rows_elem[1] + 1);
	final_square(square_1, bsq, symbols, rows_elem);
}

int	main(int argc, char **argv)
{
	int		i;
	// char	*file_name;
	int		file;
	
	if (argc == 1)
	{
		file = open("test",O_RDONLY | O_WRONLY | O_TRUNC);
		get_std_input(file);
		close(file);
		if (error_check_main("test") == 0)
			write(2, "map error\n", 11);
		else
			square_main("test");
		write(1, "\n", 1);
		
		// if (error_check_main("TEST.txt") == 0)
			// write(2, "map error\n", 10);
		// else 
			// write(1, "\n", 1);
	}
	if (argc > 1)
	{
		i = 1;
		while (i < argc)
		{
			if (error_check_main(argv[i]) == 0)
			{
				write(2, "MAP ERROR\n", 11);
			}
			else
			{
				square_main(argv[i]);
				write(1, "\n", 1);
			}
			i++;
		}
	}
	return (0);
}
