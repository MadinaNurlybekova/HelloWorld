/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vbartos <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/15 08:33:11 by vbartos           #+#    #+#             */
/*   Updated: 2022/10/15 08:33:13 by vbartos          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	first_row(int r, int x, int h)
{
	if (r == 1)
	{
		ft_putchar('/');
	}
	else if (r == x)
	{
		ft_putchar('\\');
	}
	else
	{
		ft_putchar('*');
	}			
}

int	last_row(int r, int x)
{
	if (r == 1)
	{
		ft_putchar('\\');
	}
	else if (r == x)
	{
		ft_putchar('/');
	}
	else
	{
		ft_putchar('*');
	}
}

int	middle_row(int r, int x)
{
	if (r == 1 || r == x)
	{
		ft_putchar('*');
	}
	else
	{
		ft_putchar(' ');
	}
}

int	all_rows(int r, int x, int h, int y)
{
	if (h == 1)
	{
		first_row(r, x, h);
	}			
	else if (h == y)
	{
		last_row(r, x);
	}
	else
	{
		middle_row(r, x);
	}
}

int	rush(int x, int y)
{
	int	r;
	int	h;

	h = 1;
	while (h <= y)
	{
		r = 1;
		while (r <= x)
		{
			all_rows(r, x, h, y);
			++r;
		}
		ft_putchar('\n');
		++h;
	}
}
