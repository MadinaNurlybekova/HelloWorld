/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ptrejtna <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/15 19:51:03 by ptrejtna          #+#    #+#             */
/*   Updated: 2022/10/15 19:51:17 by ptrejtna         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	first_row(int r, int x, int h)
{
	if (r == 1)
	{
		ft_putchar('A');
	}
	else if (r == x)
	{
		ft_putchar('C');
	}
	else
	{
		ft_putchar('B');
	}			
}

int	last_row(int r, int x)
{
	if (r == 1)
	{
		ft_putchar('C');
	}
	else if (r == x)
	{
		ft_putchar('A');
	}
	else
	{
		ft_putchar('B');
	}
}

int	middle_row(int r, int x)
{
	if (r == 1 || r == x)
	{
		ft_putchar('B');
	}
	else
	{
		ft_putchar(' ');
	}
}

int	all_rows(int r, int x, int h, int y)
{
	if (h == 1)
	{
		first_row(r, x, h);
	}			
	else if (h == y)
	{
		last_row(r, x);
	}
	else
	{
		middle_row(r, x);
	}
}

int	rush(int x, int y)
{
	int	r;
	int	h;

	h = 1;
	while (h <= y)
	{
		r = 1;
		while (r <= x)
		{
			all_rows(r, x, h, y);
			++r;
		}
		ft_putchar('\n');
		++h;
	}
}
