/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vbartos <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/15 08:33:11 by vbartos           #+#    #+#             */
/*   Updated: 2022/10/16 07:43:58 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	first_column(int r, int y)
{
	if (r == 1 || r == y)
	{
		ft_putchar('A');
	}
	else
	{
		ft_putchar('B');
	}
}

void	last_column(int r, int y)
{
	if (r == 1 || r == y)
	{
		ft_putchar('C');
	}
	else
	{
		ft_putchar('B');
	}
}

void	middle_column(int r, int y)
{
	if (r == 1 || r == y)
	{
		ft_putchar('B');
	}
	else
	{
		ft_putchar(' ');
	}
}

void	all_columns(int h, int r, int y, int x)
{
	if (h == 1)
	{
		first_column(r, y);
	}
	else if (h == x)
	{
		last_column(r, y);
	}
	else
	{
		middle_column(r, y);
	}
}

void	rush(int x, int y)
{
	int	r;
	int	h;

	r = 1;
	while (r <= y)
	{
		h = 1;
		while (h <= x)
		{
			all_columns(h, r, y, x);
			h++;
		}
		r++;
		ft_putchar('\n');
	}
}
