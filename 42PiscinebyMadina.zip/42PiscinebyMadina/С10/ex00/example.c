/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   example.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/30 10:35:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/30 12:42:24 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "ft.h"
#include <unistd.h>

#define BUF_SIZE 1

// void ft_write_str(int fd, char *str)
// {
//     write(fd, str, ft_strlen(str));
// }

int main(void)
{
    int fd;
    int ret;
    char buf[BUF_SIZE + 1];

    fd = open("file1", O_RDONLY);
    // fd = open("file1", O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
    if (fd == -1)
    {
        ft_putstr("open() failed\n");
        return (1);
    }
    while ((ret = read(fd, buf, BUF_SIZE)) != 0)
    {
        buf[ret] = '\0';
        // ft_putnbr(ret);
        ft_putstr(buf);
    }
    ft_putnbr(ret);
    // buf[ret] = '\0';
    // ft_putnbr(ret);
    // ft_putstr(buf);
    // ft_write_str(fd, "Hello Madi\n");
    // if (close(fd) == -1)
    // {
    //     ft_putstr("close() failed\n");
    //     return (1);
    // }
    return (0);


    // while ((ret = read(fd, buf, BUF_SIZE)) != 0)
    // {
    //     write(1, &buf, ret);
    // }
}
