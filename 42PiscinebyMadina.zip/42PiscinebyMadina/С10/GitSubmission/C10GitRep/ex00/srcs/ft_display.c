/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/30 10:35:14 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/30 12:59:21 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

void	ft_display_file(int fd)
{
	char	c;

	while (read(fd, &c, 1) != 0)
	{
		write(1, &c, 1);
	}
}

int	main(int argc, char **argv)
{
	int		fd;

	(void) argc;
	(void) argv;
	fd = open(argv[1], O_RDONLY);
	if (argc == 1)
		write(2, "File name missing.\n", 19);
	else if (argc != 2)
		write(2, "Too many arguments.\n", 20);
	else if (fd == -1)
		write(2, "Cannot read file.\n", 18);
	else
		ft_display_file(fd);
	close(fd);
	return (0);
}
