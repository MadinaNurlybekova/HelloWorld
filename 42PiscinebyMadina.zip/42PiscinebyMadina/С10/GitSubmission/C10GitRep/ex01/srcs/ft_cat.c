/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/30 13:22:23 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/30 16:01:27 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define BUF_SIZE 30000

void	ft_putstr(char *str, int output)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		write(output, &str[i], 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	int		fd;
	char	buf[BUF_SIZE + 1];

	(void) argc;
	(void) argv;
	fd = (open(argv[1], O_RDONLY));
	if (fd == -1)
	{
		ft_putstr(strerror(errno), 2);
		return (errno);
	}
	while (read(fd, buf, BUF_SIZE) != 0)
		ft_putstr(buf, 1);
	close(fd);
	return (0);
}
