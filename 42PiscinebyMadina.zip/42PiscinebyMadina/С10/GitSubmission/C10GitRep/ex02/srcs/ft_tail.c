/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 10:08:49 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/01 10:12:08 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int	ft_count_bytes(char *str)
{
	int		fd;
	int		count;
	char	c;

	fd = (open(str, O_RDONLY));
	if (fd == -1)
	{
		return (errno);
	}
	count = 0;
	while (read(fd, &c, 1) != 0)
	{
		count++;
	}
	close(fd);
	return (count);
}

void	ft_putstr_last_n_bytes(char *str, int from, int to)
{
	while (from < to)
	{
		write(1, &str[from], 1);
		from++;
	}
}

int	ft_tail(char *file, char *n_bytes)
{
	int		fd;
	char	*str;
	int		from;
	int		size;

	size = ft_count_bytes(file);
	str = malloc(sizeof(char) * size + 1);
	if (!str)
	{
		ft_putstr(strerror(errno), 2);
		return (errno);
	}
	fd = (open(file, O_RDONLY));
	ft_strdup(fd, str);
	from = size - ft_atoi(n_bytes);
	ft_putstr_last_n_bytes(str, from, size);
	close(fd);
	return (0);
}

int	main(int argc, char **argv)
{
	int	fd;

	if (argc >= 1 && argc <= 3)
		write(2, "File name missing.\n", 19);
	else if (argc != 4)
		write(2, "Too many arguments.\n", 20);
	else
	{
		fd = open(argv[3], O_RDONLY);
		if (fd == -1)
		{
			ft_putstr(strerror(errno), 2);
			return (errno);
		}
		else
		{
			close(fd);
			ft_tail(argv[3], argv[2]);
		}
	}
	return (0);
}
