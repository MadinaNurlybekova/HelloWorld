/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rev_print.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 15:46:13 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 15:55:33 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int counter(char *str)
{
    int counter;
    counter = 0;
    while (str[counter] != '\0')
    {
        counter++;
    }
    return (counter);
}

char *ft_rev_print (char *str)
{
    int i;
    i = counter(str) - 1;

    while (i != 0)
    {
        write(1, &str[i], 1);
        i--;
    }
    write(1, "\n", 1);
    return (str);
}

int main()
{
	char str[] = "dub0 a POIL";
	ft_rev_print(str);
}
