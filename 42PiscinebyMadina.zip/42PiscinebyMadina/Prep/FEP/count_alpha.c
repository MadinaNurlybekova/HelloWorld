/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   count_alpha.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 13:23:08 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 21:28:45 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct s_struct{
    int nbr;
    char c;
} t_struct;

int ft_strlen(char *str)
{
    int i;
    i = 0;
    while (str[i] != '\0')
        i++;
    return (i);
}

void    ft_lowercase(char *str)
{
    int i;
    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
        i++;
    }
}

int count_in_str(char c, char *str)
{
    int counter;
    int i;
    counter = 0;
    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] == c)
        {
            counter++;
        }
        i++;
    }
    return (counter);
}

int check_if_repeat(char c, char *alpha_arr)
{
    int i = 0;
    while (alpha_arr[i] != '\0')
    {
        if (alpha_arr[i] == c)
            return (1);
        i++;
    }
    return (0);
}

void	positive_number(int nb)
{
	char	c;
	char	arr[20];
	int		i;
	int		len;

	i = 0;
	while (nb > 0)
	{
		c = (nb % 10) + '0';
		arr[i] = c;
		nb = nb / 10;
		i++;
	}
	len = i - 1;
	while (len >= 0)
	{
		write(1, &arr[len], 1);
		len--;
	}
}

void	ft_putnbr(int nb)
{
	if (nb == 0)
		write(1, "0", 1);
	else if (nb > 0)
	{
		positive_number(nb);
	}
	else if (nb == -2147483648)
		write (1, "-2147483648", 11);
	else
	{
		nb = nb * (-1);
		write(1, "-", 1);
		positive_number(nb);
	}
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void    ft_show_tab(struct s_struct *lol, int len)
{
    int i;
    i = 0;

    while (lol[i].c != 0)
    {
        ft_putnbr(lol[i].nbr);
        ft_putchar(lol[i].c);
        if (i < len - 1)
            write(1, ", ", 2);
        i++;
    }
}

void    count_alpha(char *str)
{
    int counter;
    char *alpha_arr;
    int len;
    int arr_i;
    int i;
    struct s_struct *res_arr; 
    
    len = ft_strlen(str);
    alpha_arr = malloc(sizeof(char) * len + 1);
    res_arr = malloc(sizeof(struct s_struct) * len + 1);
    i = 0;
    arr_i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 'a' && str[i] <= 'z')
        {
            if (check_if_repeat(str[i], alpha_arr) == 0)
            {
                alpha_arr[arr_i] = str[i];
                counter = count_in_str(str[i], str);
                res_arr[arr_i].nbr = counter;
                res_arr[arr_i].c = str[i];
                arr_i++;
            }
        }    
        i++;
    }
    res_arr[arr_i].c = 0;
    ft_show_tab(res_arr, arr_i);
}

int main(int argc, char **argv)
{
    if (argc == 2)
    {
        if (argv[1][0] == '\0')
            write(1, "\n", 1);
        else
        {
            ft_lowercase(argv[1]);
            count_alpha(argv[1]); 
        }
    }
    else
        write(1, "\n", 1);
    return (0);
}