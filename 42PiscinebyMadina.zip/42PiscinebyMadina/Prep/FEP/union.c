/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   union.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 19:04:47 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 19:43:03 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int check_1(char *str, char c)
{
    int i;
    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] == c)
            return (1);
        i++;
    }
    return (0);
}

int check_2(char *str, char c, int position)
{
    int j;
    j = 0;
    while (j < position)
    {
        if (str[j] == c)
            return (1);
        j++;
    }
    return (0);
}

int main(int argc, char **argv)
{
    int i;
    int j;
    i = 0;
    if (argc == 3)
    {
        while (argv[1][i] != '\0')
        {
            if (check_2(argv[1], argv[1][i], i) == 0)
                write(1, &argv[1][i], 1);
            i++;
        }
        j = 0;
        while (argv[2][j] != '\0')
        {
            if (check_1(argv[1], argv[2][j]) == 0)
            {
                if (check_2(argv[2], argv[2][j], j) == 0)
                {
                    write(1, &argv[2][j], 1);
                }
            }
            j++;
        }
    }
    write(1, "\n", 1);
    return (0);
}