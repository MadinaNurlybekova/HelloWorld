/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 10:01:22 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 10:19:58 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int abs_value(int x)
{
    if (x < 0)
        return (x * -1);
    return (x);
}


int     *ft_range(int start, int end)
{
    int i;
    int len;
    int *arr;

    len = abs_value(end - start); 
    
    arr = malloc(sizeof(int) * len + 1);
    if (arr == 0)
        return (0);
    i = 0;
    if (len == 0)
    {
        arr[0] = start;
    }
    else if (start < end)
    {
        while (i <= len)
        {
            arr[i] = start;
            start++;              
            i++;
        }
    }
    else if (start > end)
    {
        while (i <= len)
        {
            arr[i] = start;
            start--;              
            i++;
        }
    }
    return (arr);
}

int     main(void)
{
    int i = 0;
    int start = 5;
    int end = 5;
    int len = abs_value(end - start);
    int *arr;
    arr = ft_range(start, end);
    while (i <= len)
    {
        printf("%d\n", arr[i]);
        i++; 
    }
}