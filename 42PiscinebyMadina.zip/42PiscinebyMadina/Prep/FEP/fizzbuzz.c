/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fizzbuzz.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 13:40:27 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 15:45:49 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void    ft_write_number(int i)
{
    if (i > 9)
        ft_write_number(i/10);
    write(1, &"0123456789"[i%10], 1);
}

int main()
{
    int i;
    i = 1;
    while (i < 101)
    {
        if ((i % 3 == 0) && (i % 5 == 0))
            write(1, "fizzbuzz", 8);
        else if (i % 3 == 0)
            write(1, "fizz", 4);
        else if (i % 5 == 0)
            write(1, "buzz", 4);
        else
            ft_write_number(i);
        write(1, "\n", 1);
        i++;
    }
    return (0);
}

