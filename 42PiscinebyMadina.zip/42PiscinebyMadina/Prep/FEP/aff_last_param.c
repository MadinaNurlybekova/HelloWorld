/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aff_last_param.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 15:55:38 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 16:00:58 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void    ft_putstr(char *str)
{
    int i = 0;
    
    while (str[i] != '\0')
    {
        write(1, &str[i], 1);
        i++;
    }
}

int main(int argc, char** argv)
{
    int i = 1;
    if (argc >= 2)
    {
        while (i < argc)
        {
            if (i == argc - 1)
            {
                ft_putstr(argv[i]);
            }
            i++;
        }
    }
    write(1, "\n", 1);
    return (0);
}