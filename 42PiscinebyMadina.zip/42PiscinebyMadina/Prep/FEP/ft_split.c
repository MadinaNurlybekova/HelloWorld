/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 10:20:11 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 15:35:01 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int check_if_separator(char c)
{   
    if (c == '\n' || c == ' ' || c == '\t' || c == '\0')
        return (1);
    return (0);
}

int count_words(char *str)
{
    int counter;
    int i;
    counter = 0;
    i = 0;
    while (str[i] != '\0')
    {
        if (check_if_separator(str[i]) == 1 && check_if_separator(str[i + 1]) == 0)
            counter++;
        i++;
    }
    return (counter + 1);
}

char *ft_wordup(char *str, int start, int finish)
{
    char *word;
    int i;

    i = 0;
    word = malloc(sizeof(char) * (finish - start + 1));
    while (start < finish)
    {
        word[i] = str[start];
        i++;
        start++;
    }
    word[i] = '\0';
    return (word);
}

char    **ft_split(char *str)
{
    int length;
    char **arr;
    int i;
    int j;
    int arr_i;
    
    length = count_words(str);
    arr = malloc(sizeof(char *) * length + 1);
    if (!(arr))
        return (0);
    i = 0;
    arr_i = 0;
    while (str[i] != '\0')
    {
        if (check_if_separator(str[i]) == 1)
            i++;
        else
        {
            j = 0;
            while (check_if_separator(str[j+i]) == 0)
                j++;
            arr[arr_i] = ft_wordup(str, i, j + i);
            arr_i++;
            i += j;
        } 
    }
    arr[arr_i] = 0;
    return (arr);
}

int main(void)
{
    char arr[] = "Write a function that takes a string, splits it into words, and returns them as a NULL-terminated array of strings.";
    char **arr_result;
    arr_result = ft_split(arr);
    int i = 0;
    while (arr_result[i] != 0)
    {
        printf("%s\n", arr_result[i]);
        i++;
    }
    return (0);
}  