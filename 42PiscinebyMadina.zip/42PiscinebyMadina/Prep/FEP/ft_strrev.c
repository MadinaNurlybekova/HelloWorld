/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 16:58:21 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 17:11:16 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putstr(char *str)
{
    int i = 0;
    while (str[i] != '\0')
    {
        write(1, &str[i], 1);
        i++; 
    }
}

int ft_strlen(char *str)
{
    int counter;
    counter = 0;
    while (str[counter] != '\0')
        counter++;
    return (counter);   
}

char    *ft_strrev(char *str)
{
    char tmp;
    int i;
    int j;
    i = 0;
    j = ft_strlen(str) - 1;
    
    while (i < j)
    {
        tmp = str[i];
        str[i] = str[j];
        str[j] = tmp;
        i++;
        j--;
    }
    return (str);
}

int main(void)
{
    char str[] = "madilna";
    ft_strrev(str);
    ft_putstr(str);
    return (0);
}