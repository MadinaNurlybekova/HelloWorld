/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ulstr.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 16:50:48 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 16:56:48 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void    change_case(char *str)
{
    int i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
        else if (str[i] >= 'a' && str[i] <= 'z')
            str[i] -= 32;
        i++;
    }
}

int main(int argc, char **argv)
{
    int i = 0;
    if (argc == 2)
    {
        change_case(argv[1]);
        while(argv[1][i] != '\0')
        {
            write(1, &argv[1][i], 1);
            i++;
        }            
    }
    write(1, "\n", 1);
    return (0);
}