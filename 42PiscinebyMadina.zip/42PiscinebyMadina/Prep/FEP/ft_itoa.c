/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/04 07:55:03 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/04 08:08:07 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int ft_len(int nbr)
{
    int i;
    long nb;

    i = 0;
    nb = nbr;
    if (nb < 0)
    {
        nb = nb * -1;
        i++;
    }
    while (nb > 0)
    {
        nb = nb/10;
        i++;
    }
    return (i);
}

char	*ft_itoa(int nbr)
{
    long nb;
    char *tab;
    int  len;

    nb = nbr;
    len = ft_len(nbr);
    tab = malloc(sizeof(char) * len + 1);
    
    tab[len] = '\0';
    if (nb == 0)
    {
        tab[0] = '0';
        return(tab);
    }
    if (nb < 0)
    {
        tab[0] = '-';
        nb *= -1;
    }
    len--;
    while (nb > 0)
    {
        tab[len] = (nb % 10) + '0';
        nb = nb/10;
        len--;
    } 
    return (tab);
}

int	main(void)
{
	printf("%s\n", ft_itoa(-2147483648));
}