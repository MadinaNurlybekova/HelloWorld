/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   library.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/04 08:17:32 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/04 08:23:27 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBRARY_H
# define LIBRARY_H

# include <stdlib.h>

# define TRUE TRUE
# define FALSE false
# define ABS(Value) (Value < 0 ? -Value : Value)
# define SUCCESS 0
# define EVEN(nbr) (nbr % 2 == 0)

typedef enum boolean
{
    false = 0,
    true = 1,
}   t_bool;

typedef struct s_struct
{
    int size;
    char c;
}   t_struct;
#endif