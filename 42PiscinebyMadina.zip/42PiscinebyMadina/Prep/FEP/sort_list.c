/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_list.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/04 07:50:37 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/04 07:56:04 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include "list.h"

t_list	*sort_list(t_list* lst, int (*cmp)(int, int))
{
    int swap;
    t_list *tmp;
    
    tmp = lst;

    while (lst->next != 0)
    {
        if (((*cmp)(lst->data, lst->next->data)) == 0)
        {
            
            swap = lst->data;
            lst->data = lst->next->data;
            lst->next->data = swap;
            lst = tmp;
        }
        else
            {
                lst = lst->next;
            }
    }
    lst = tmp;
    return (lst);
}