git log --format=tformat:'%H' -n5
