/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/23 09:40:36 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 11:12:46 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stdio.h>
#include <unistd.h>
#include <string.h>

// #include "ex00/ft_strlen.c"
// #include "ex01/ft_putstr.c"
// #include "ex02/ft_putnbr.c"
// #include "ex03/ft_atoi.c"
// #include "ex04/ft_putnbr_base.c"
#include "ex05/ft_atoi_base.c"

int main()
{
	//00
    // printf("len: %d", ft_strlen("Martin likes chicken with rice"));
    
	//01
    // ft_putstr("Some random string madina");

	//02
	// ft_putnbr(-2147483648);
	// write(1, "\n", 1);
	// ft_putnbr(2147483647);
	// write(1, "\n", 1);
	// ft_putnbr(5);
	// write(1, "\n", 1);
	// ft_putnbr(0);
	// write(1, "\n", 1);
	// ft_putnbr(15);

	//03
    // char	str[] = "   -+-++--- 2147483648---s-df";
	// int	val = ft_atoi(str);
	// printf("%d", val);
	// return (0);

    // 04
    // ft_putnbr_base(3861, "0123456789ABCDEF");
    // ft_putnbr_base(-2147483648, "01");
    // ft_putnbr_base(2147483647, "poneyvif");
    // ft_putnbr_base(-2147483648, "01234567");

    // 05
    printf("%d\n", ft_atoi_base("   +----539", "012034567"));
	// printf("%d\n", ft_atoi_base("       --++---10000000000000000000000000000000", " 01"));
	// printf("%d\n", ft_atoi_base(" --+--+-80000000-C567", "0123456789ABCDEF "));
	// printf("%d", ft_atoi_base(" ---+--+pyb567", "poneyvif"));

    return(0);
}
