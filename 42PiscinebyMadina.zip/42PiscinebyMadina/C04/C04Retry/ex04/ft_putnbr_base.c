/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/20 13:19:13 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/23 11:44:10 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	base_error_check(char *base)
{
	int	i;
	int	j;

	i = 0;
	if (base[0] == '\0' || ft_strlen(base) == 1)
		return (0);
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-' || base[i] < 32 || base[i] > 126)
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	positive_num_putnbr_base(long nbr_long, char *base)
{
	char	arr[100000];
	int		len_base;
	int		j;

	len_base = ft_strlen(base);
	j = 0;
	while (nbr_long != 0)
	{
		arr[j] = base[nbr_long % len_base];
		nbr_long = nbr_long / len_base;
		j++;
	}
	while (--j != -1)
	{
		write (1, &arr[j], 1);
	}
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		error_check;
	long	nbr_long;

	error_check = base_error_check(base);
	if (error_check == 1)
	{
		nbr_long = nbr;
		if (nbr_long == 0)
		{
			write(1, &base[nbr_long], 1);
		}
		else if (nbr_long > 0)
			positive_num_putnbr_base(nbr_long, base);
		else
		{
			nbr_long = nbr_long * (-1);
			write(1, "-", 1);
			positive_num_putnbr_base(nbr_long, base);
		}
	}
}
