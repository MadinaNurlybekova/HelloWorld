/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/20 09:47:27 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/23 10:22:55 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	positive_number(int nb)
{
	char	c;
	char	arr[20];
	int		i;
	int		len;

	i = 0;
	while (nb > 0)
	{
		c = (nb % 10) + '0';
		arr[i] = c;
		nb = nb / 10;
		i++;
	}
	len = i - 1;
	while (len >= 0)
	{
		write(1, &arr[len], 1);
		len--;
	}
}

void	ft_putnbr(int nb)
{
	if (nb == 0)
		write(1, "0", 1);
	else if (nb > 0)
	{
		positive_number(nb);
	}
	else if (nb == -2147483648)
		write (1, "-2147483648", 11);
	else
	{
		nb = nb * (-1);
		write(1, "-", 1);
		positive_number(nb);
	}
}
