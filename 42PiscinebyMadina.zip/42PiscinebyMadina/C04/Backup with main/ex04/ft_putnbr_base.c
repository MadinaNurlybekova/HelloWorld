/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/20 13:19:13 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/22 17:48:11 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	base_error_check(char *base)
{
	int	i;
	int	j;

	i = 0;
	if (base[0] == '\0' || ft_strlen(base) == 1)
		return (0);
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-' || base[i] <= 32 || base[i] == 127)
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	positive_num_putnbr_base(int nbr, char *base)
{
	char	arr[10000];
	int		len_base;
	int		j;

	len_base = ft_strlen(base);
	j = 0;
	while (nbr)
	{
		arr[j] = base[nbr % len_base];
		nbr = nbr / len_base;
		j++;
	}
	while (--j >= 0)
	{
		write (1, &arr[j], 1);
	}
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	error_check;

	error_check = base_error_check(base);
	if (error_check == 1)
	{
		if (nbr == 0)
		{
			write(1, &base[nbr], 1);
		}
		else if (nbr > 0)
			positive_num_putnbr_base(nbr, base);
		else
		{
			nbr = nbr * (-1);
			write(1, "-", 1);
			positive_num_putnbr_base(nbr, base);
		}
	}
}
