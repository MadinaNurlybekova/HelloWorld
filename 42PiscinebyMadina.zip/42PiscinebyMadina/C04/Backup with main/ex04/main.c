#include "ft_putnbr_base.c"

void ft_putnbr_base(int nbr, char *base);

int main() 
{
    // ft_putnbr_base(3681, "0123456789ABCDEF"); //what about -2147483648
    // ft_putnbr_base(3681, "01");
    // ft_putnbr_base(3681, "poneyvif");
    // ft_putnbr_base(3681, "01234567");
    return 0;
}