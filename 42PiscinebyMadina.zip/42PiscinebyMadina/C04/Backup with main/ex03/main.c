/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/20 13:15:21 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/22 17:48:09 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_atoi.c"
#include <string.h>
#include <stdio.h>

int	main(void)
{
	char	str[] = "   ----1236-s-df";

	int	val = ft_atoi(str);
	printf("%d", val);
	return (0);
}
