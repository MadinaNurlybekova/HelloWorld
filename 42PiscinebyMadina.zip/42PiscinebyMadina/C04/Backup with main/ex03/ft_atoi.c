/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/20 11:11:17 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/20 13:18:16 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	sign_check(int count_sign)
{
	if (count_sign % 2 == 0)
		return (1);
	else
		return (-1);
}

int	ft_atoi(char *str)
{
	int	result;
	int	i;
	int	count_sign;
	int	sign;

	count_sign = 0;
	result = 0;
	i = 0;
	while (str[i] == ' ' || str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
		{
			count_sign++;
		}
		i++;
	}
	sign = sign_check(count_sign);
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = result * 10 + str[i] - '0';
		i++;
	}
	return (result * sign);
}
