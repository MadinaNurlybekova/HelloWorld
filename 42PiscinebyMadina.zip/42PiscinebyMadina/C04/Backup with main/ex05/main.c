/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/22 11:29:30 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/22 17:14:45 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft_atoi_base.c"

int	ft_atoi_base(char *str, char *base);

int	main(void)
{
	// printf("%d", ft_atoi_base("   +----539", "01234567"));
	// printf("%d", ft_atoi_base("       --++--101010", "01"));
	// printf("%d", ft_atoi_base(" ---+--+1234AB-C567", "0123456789ABCDEF"));
	// printf("%d", ft_atoi_base(" ---+--+pyb567", "poneyvif"));
	return (0);
}
