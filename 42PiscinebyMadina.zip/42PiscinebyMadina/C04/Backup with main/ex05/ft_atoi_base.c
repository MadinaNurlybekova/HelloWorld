/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/22 11:14:24 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/22 17:14:15 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	base_error_check(char *base)
{
	int	i;
	int	j;

	i = 0;
	if (base[0] == '\0' || base[1] == '\0')
		return (0);
	while (base[i] != '\0')
	{
		if ((base[i] >= 9 && base[i] <= 13) || base[i] == 32
			|| base[i] == 43 || base[i] == 45)
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (i);
}

int	str_clean_up(char *str, char *base, int i)
{
	int	j;
	int	counter;
	int	nbr;

	nbr = 0;
	while (str[i] != '\0')
	{
		j = 0;
		counter = 0;
		while (j < base_error_check(base))
		{
			if (str[i] == base[j])
			{
				nbr = (nbr * base_error_check(base)) + j;
				counter++;
			}
			j++;
		}
		if (counter == 0)
			break ;
		i++;
	}
	return (nbr);
}

int	ft_atoi_base(char *str, char *base)
{
	int	i;
	int	sign;
	int	result;

	if (base_error_check(base) > 1)
	{
		i = 0;
		sign = 1;
		while (str[i] == ' ' || str[i] == '-' || str[i] == '+')
		{
			if (str[i] == '-')
				sign *= -1;
			i++;
		}
		result = str_clean_up(str, base, i);
		return (result * sign);
	}
	else
		return (0);
}
