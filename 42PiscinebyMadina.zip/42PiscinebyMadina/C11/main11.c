/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main11.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 11:31:19 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 16:07:28 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stdio.h>


// ex00
// #include "ex00/ft_foreach.c"
// #include "ft_putnbr.c"
// int main(void)
// {
//     int *tab;
//     int i;
//     int length;

//     i = 0;
//     length = 20;
//     tab = malloc(length * sizeof(int));
//     while (i < length)
// 	{
// 		tab[i] = i;
// 		i++;
// 	}
    
//     ft_foreach(tab, 20, &ft_putnbr);
//     free(tab);
//     return (0);
// }

// ex01
#include "ex01/ft_map.c"
int ft_mul(int a)
{
	return (a * 3);
}
int main(void)
{
    int *tab;
    int i;
    int length;
    int *arr;

    i = 0;
    length = 10;
    tab = malloc(length * sizeof(int));
    while (i < length)
	{
		tab[i] = i;
		i++;
	}
    
    arr = ft_map(tab, 10, &ft_mul);
    int j = 0;
    while (j < length)
    {
        printf("%d, ", arr[j]);
        j++;
    }
    free(tab);
    free (arr);
    return (0);
}

// ex02
// #include "ex02/ft_any.c"
// int ft(char *str)
// {
// 	if (*str == 'Z')
// 		return (1);
// 	return (0);
// }
// int main (void)
// {
// 	char **array;

// 	array = malloc(3 * sizeof(char *));
// 	array[0] = NULL;
// 	array[1] = NULL;
// 	array[2] = NULL;

// 	printf("%d\n", ft_any(array, ft));

// }

// ex04
// #include "ex04/ft_is_sort.c"#include "ex01/ft_map.c"
// int ft_mul(int a)
// {
// 	return (a * 3);
// }
// int main(void)
// {
//     int *tab;
//     int i;
//     int length;
//     int *arr;

//     i = 0;
//     length = 10;
//     tab = malloc(length * sizeof(int));
//     while (i < length)
// 	{
// 		tab[i] = i;
// 		i++;
// 	}
    
//     arr = ft_map(tab, 10, &ft_mul);
//     int j = 0;
//     while (j < length)
//     {
//         printf("%d, ", arr[j]);
//         j++;
//     }
//     free(tab);
//     free (arr);
//     return (0);
// }

// 	if (x < y)
// 		return (-1);
// 	else if (x == y)
// 		return (0);
// 	else
// 		return (1);
// }

// int main (void)
// {
// 	int	tab1[] = {1, 84, 561, 21, 94, 1000, 3, 5, 4, 89, 654, 23, 23};
//     int	tab2[] = {-5, 1, 3, 5, 9, 15};
//     int	tab3[] = {1000, 888, 777, 156, 99, 0, -56};
//     int	tab4[] = {12, 16, 89, 456, 0, 123438};

// 	printf("%d\n", ft_is_sort(tab1, 13, &ft_nbr));
//     printf("%d\n", ft_is_sort(tab2, 5, &ft_nbr));
//     printf("%d\n", ft_is_sort(tab3, 7, &ft_nbr));
//     printf("%d\n", ft_is_sort(tab4, 5, &ft_nbr));
// }


