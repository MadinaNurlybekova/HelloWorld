/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/01 12:43:46 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 13:14:53 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int check_div_zero(int ope_i, int b)
{
    if (ope_i == 3 && b == 0)
    {
        write(1, "Stop : division by zero", 23);
        return (0);
    }
    else if (ope_i == 4 && b == 0)
    {
        write(1, "Stop : modulo by zero", 21);
        return (0);
    }
    else
        return (1);
}
    // printf("%d", value1);
    // printf("%c", argv[0]);
    // printf("%d", value2);
void	ft_do_op(char operator, int a, int b)
{
    int (*calculation[5])(int, int);
    int ope_i;
    
    calculation[0] = &calc_add;
    calculation[1] = &calc_sub;
    calculation[2] = &calc_mul;
    calculation[3] = &calc_div;
    calculation[4] = &calc_mod;
    ope_i = check_operator(operator);
    printf("%d", ope_i);
    if (ope_i != -1)
    {
        if (check_div_zero(ope_i, b) == 1)
        {
            ft_putnbr(calculation[ope_i](a, b)); 
        }
    }
    else
    {
        ft_putnbr(0);
    }
}

int main(int argc, char **argv)
{
    int a;
    int b;

    if (argc == 4)
    {
        a = ft_atoi(argv[1]);
        b = ft_atoi(argv[3]);
        ft_do_op(argv[2][0], a, b);
        write(1, "\n", 1);
    }
    return (0);
}
