/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_operator.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/02 11:30:09 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 13:15:39 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int check_operator(char operator)
{
    int i;
    char *op_signs;
    
    op_signs = "+-*/%";
    
    while (op_signs[i] != '\0')
    {
        if (op_signs[i] == operator)
        {
            printf("%d", i);
            return (i);
        }
    }
    return (-1);
}