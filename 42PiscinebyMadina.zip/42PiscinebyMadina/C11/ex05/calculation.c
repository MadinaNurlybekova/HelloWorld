/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   calculation.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/02 12:49:17 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 13:13:24 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		calc_add(int a, int b)
{
	return (a + b);
}

int		calc_sub(int a, int b)
{
	return (a - b);
}

int		calc_mul(int a, int b)
{
	return (a * b);
}

int		calc_div(int a, int b)
{
	return (a / b);
}

int		calc_mod(int a, int b)
{
	return (a % b);
}
