/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/02 11:30:37 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/02 13:15:10 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# include <unistd.h>
# include <stdlib.h>
# include <unistd.h>
# include <stdio.h>


int check_operator(char operator);
int     ft_atoi(char *str);
int     ft_isspace(int i, char *str);
void	ft_putnbr(int nb);
void	positive_number(int nb);
int check_div_zero(int ope_i, int b);
void	ft_do_op(char operator, int a, int b);
int		calc_add(int a, int b);
int		calc_sub(int a, int b);
int		calc_div(int a, int b);
int		calc_mod(int a, int b);
int		calc_mul(int a, int b);

#endif