/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/19 15:21:18 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/19 21:17:01 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	counter;

	counter = 0;
	while (str[counter] != '\0')
	{
		counter++;
	}
	return (counter);
}

char	*ft_strstr(char *str, char *to_find)
{
	int	len_what;
	int	i;
	int	j;

	len_what = ft_strlen(to_find);
	i = 0;
	if (to_find[0] == '\0')
	{
		return (str);
	}
	while (str[i] != '\0')
	{
		j = 0;
		while (str[i + j] == to_find[j] && j != len_what)
		{
			j++;
			if (j == len_what)
			{
				return (str + i);
			}
		}
		i++;
	}
	return (0);
}
