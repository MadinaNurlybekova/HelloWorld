/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/29 18:09:20 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/29 18:09:53 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char    *ft_strncat(char *dest, char *src, int n)
{
    int i;
    int j;
    i = 0;
    j = 0;
    while (dest[i] != '\0')
    {
        i++;
    }

    printf("%d this is the index \n", i);
    while (src[j] != '\0' && j < n)
    {
        dest[i] = src[j];
        j++;
        i++;
    }
    dest[i] = '\0';
    return (dest);
}