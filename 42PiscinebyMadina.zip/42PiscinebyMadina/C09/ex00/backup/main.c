
#include <stdio.h>
#include "ft.h"
#include "ft_putchar.c"

int main(void)
{
	ft_putchar('c');
	return (0);
}
