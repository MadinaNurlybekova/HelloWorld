/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main08.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 16:03:02 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/11/03 12:55:36 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// ===========EX00=============
// #include "ex00/ft.h"
// int main()
// {
//     return (0);
// }

// ===========EX01=============
#include "ex01/ft_boolean.h"
void ft_putstr(char *str)
{
    while (*str)
        write(1, str++, 1);
}

t_bool ft_is_even(int nbr)
{
    return ((EVEN(nbr)) ? TRUE : FALSE);
}

int main(int argc, char **argv)
{
    (void)argv;
    if (ft_is_even(argc - 1) == TRUE)
        ft_putstr(EVEN_MSG);
    else
        ft_putstr(ODD_MSG);
    return (SUCCESS);
}

char *pointer; 
char m;

pointer = &m;


// ===========EX02=============
// #include <stdio.h>
// #include "ex02/ft_abs.h"
// int main()
// {
//     long x = -2147483648;
    
//     printf("Absolute Value of x is %ld", ABS(x));
//     return(x);
// }

// ===========EX03=============

// #include "ex03/ft_point.h"

// void    set_point(t_point *point)
// {
//     point->x = 42;
//     point->y = 21;
// }
// int main(void)
// {
//     t_point point;

//     set_point(&point);
//     return (0);
// }

// ===========EX04=EX05==========
// #include "ex04/ft_stock_str.h"
// #include "ex04/ft_strs_to_tab.c"
// #include "ex05/ft_show_tab.c"

// int					main(void)
// {
// 	char	*strs[5];
// 	char	*str1;
// 	char	*str2;
// 	char	*str3;
// 	char	*str4;
//     char	*str5;
// 	int		size;

// 	str1 = "Hello";
// 	str2 = "Wall";
// 	str3 = "Wextra";
// 	str4 = "Werror";
//     str5 = "Magnificent";
// 	size = 5;
// 	strs[0] = str1;
// 	strs[1] = str2;
// 	strs[2] = str3;
// 	strs[3] = str4;
//     strs[4] = str5;
// 	ft_show_tab(ft_strs_to_tab(size, strs));
//     free(ft_strs_to_tab(size, strs));
// }
