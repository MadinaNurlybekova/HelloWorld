/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   c08ex01.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/27 15:10:04 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 15:12:04 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef C08EX01_H
# define C08EX01_H
# define EVEN_MSG "I have an even number of arguments."
# define ODD_MSG "I have an odd number of arguments."
# define SUCCESS 0
# define TRUE 1
# define FALSE 0
# define EVEN(nbr) (nbr % 2 == 0)

# include <unistd.h>

typedef _Bool	t_bool;

#endif