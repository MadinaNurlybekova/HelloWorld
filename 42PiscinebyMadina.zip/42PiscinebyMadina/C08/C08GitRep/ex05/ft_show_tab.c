/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/27 10:01:16 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 10:43:00 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "ft_stock_str.h"

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	positive_number(int nb)
{
	char	c;
	char	arr[20];
	int		i;
	int		len;

	i = 0;
	while (nb > 0)
	{
		c = (nb % 10) + '0';
		arr[i] = c;
		nb = nb / 10;
		i++;
	}
	len = i - 1;
	while (len >= 0)
	{
		write(1, &arr[len], 1);
		len--;
	}
}

void	ft_putnbr(int nb)
{
	if (nb == 0)
		write(1, "0", 1);
	else if (nb > 0)
	{
		positive_number(nb);
	}
	else if (nb == -2147483648)
		write (1, "-2147483648", 11);
	else
	{
		nb = nb * (-1);
		write(1, "-", 1);
		positive_number(nb);
	}
}

void	ft_show_tab(struct s_stock_str *par)
{
	int	i;

	i = 0;
	while (par[i].str != 0)
	{
		ft_putnbr(par[i].size);
		ft_putchar('\n');
		ft_putstr(par[i].str);
		ft_putchar('\n');
		ft_putstr(par[i].copy);
		ft_putchar('\n');
		i++;
	}
}
