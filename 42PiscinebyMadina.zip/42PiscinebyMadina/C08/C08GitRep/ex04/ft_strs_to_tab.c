/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mnurlybe <mnurlybe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/25 18:30:10 by mnurlybe          #+#    #+#             */
/*   Updated: 2022/10/27 10:42:05 by mnurlybe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_stock_str.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

char	*ft_strdup(char *src)
{
	int			i;
	char		*duplicate;

	i = 0;
	while (src[i] != '\0')
		i++;
	duplicate = malloc(sizeof(char *) * (i + 1));
	if (duplicate == NULL)
		return (0);
	else
	{
		i = 0;
		while (src[i] != '\0')
		{
			duplicate[i] = src[i];
			i++;
		}
		duplicate[i] = '\0';
	}
	return (duplicate);
}

struct	s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	struct s_stock_str	*my_array;
	int					i;

	my_array = (struct s_stock_str *)malloc(sizeof(t_stock_str) * (ac + 1));
	if (my_array == 0)
		return (0);
	i = 0;
	while (i < ac)
	{
		my_array[i].size = ft_strlen(av[i]);
		my_array[i].str = av[i];
		my_array[i].copy = ft_strdup(av[i]);
		i++;
	}
	my_array[i].str = 0;
	return (my_array);
}
